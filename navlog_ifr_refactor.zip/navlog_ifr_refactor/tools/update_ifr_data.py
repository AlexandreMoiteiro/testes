#!/usr/bin/env python3
"""
Atualizador offline dos dados IFR para a app NAVLOG.

Uso:
    python tools/update_ifr_data.py

Gera/atualiza na raiz do repo:
    IFR_POINTS.csv   — ENR 4.4 Name-code Designators for Significant Points
    IFR_AIRWAYS.csv  — sequências simples extraídas de ENR 3.3 Area Navigation Routes

A app Streamlit NÃO chama este script. É manual, para quando quiseres atualizar AIRAC.

Notas:
- O HTML do eAIP muda de estrutura; este parser tenta ser tolerante.
- Valida sempre o CSV final antes de uso operacional.
"""
from __future__ import annotations

import csv
import re
from pathlib import Path
from typing import Dict, Iterable, List, Tuple

import requests
from bs4 import BeautifulSoup

ROOT = Path(__file__).resolve().parents[1]
URL_ENR44 = "https://ais.nav.pt/wp-content/uploads/AIS_Files/eAIP_Current/eAIP_Online/eAIP/html/eAIP/LP-ENR-4.4-en-GB.html"
URL_ENR33 = "https://ais.nav.pt/wp-content/uploads/AIS_Files/eAIP_Current/eAIP_Online/eAIP/html/eAIP/LP-ENR-3.3-en-PT.html?amdt=show"

POINT_RE = re.compile(r"^[A-Z][A-Z0-9]{2,4}$")
LAT_RE = re.compile(r"^\d{6}(?:\.\d+)?N$|^\d{6}(?:\.\d+)?S$")
LON_RE = re.compile(r"^\d{7}(?:\.\d+)?E$|^\d{7}(?:\.\d+)?W$")
ROUTE_RE = re.compile(r"\b(?:U?[A-Z]{1,2}\d{1,3}|[A-Z]\d{1,3})\b")


def text_lines(url: str) -> List[str]:
    r = requests.get(url, timeout=45, headers={"User-Agent": "navlog-ifr-data-updater/1.0"})
    r.raise_for_status()
    soup = BeautifulSoup(r.text, "html.parser")
    for tag in soup(["script", "style"]):
        tag.decompose()
    lines = [x.strip().replace("\xa0", " ") for x in soup.get_text("\n").splitlines()]
    return [x for x in lines if x]


def dms_to_dd(token: str, is_lon: bool) -> float:
    token = token.strip().upper()
    hemi = token[-1]
    value = token[:-1]
    deg_len = 3 if is_lon else 2
    deg = int(value[:deg_len])
    minutes = int(value[deg_len:deg_len + 2])
    seconds = float(value[deg_len + 2:])
    dd = deg + minutes / 60 + seconds / 3600
    if hemi in {"S", "W"}:
        dd = -dd
    return dd


def parse_enr44() -> List[Dict[str, str]]:
    lines = text_lines(URL_ENR44)
    rows: List[Dict[str, str]] = []
    i = 0
    while i < len(lines) - 2:
        code = lines[i].strip().upper()
        lat = lines[i + 1].strip().upper() if i + 1 < len(lines) else ""
        lon = lines[i + 2].strip().upper() if i + 2 < len(lines) else ""
        if POINT_RE.match(code) and LAT_RE.match(lat) and LON_RE.match(lon):
            j = i + 3
            meta: List[str] = []
            while j < len(lines):
                # Stop at next point+lat+lon triple.
                if j + 2 < len(lines) and POINT_RE.match(lines[j].upper()) and LAT_RE.match(lines[j + 1].upper()) and LON_RE.match(lines[j + 2].upper()):
                    break
                meta.append(lines[j])
                j += 1
            meta_txt = " ".join(meta)
            routes = " ".join(sorted(set(ROUTE_RE.findall(meta_txt))))
            rows.append({
                "code": code,
                "name": code,
                "lat": f"{dms_to_dd(lat, False):.6f}",
                "lon": f"{dms_to_dd(lon, True):.6f}",
                "routes": routes,
                "remarks": re.sub(r"\s+", " ", meta_txt).strip(),
                "src": "IFR",
            })
            i = j
        else:
            i += 1
    return rows


def parse_enr33(points_by_code: Dict[str, Dict[str, str]]) -> List[Dict[str, str]]:
    lines = text_lines(URL_ENR33)
    out: List[Dict[str, str]] = []
    current_route = ""
    seq_by_route: Dict[str, int] = {}

    # The eAIP text repeats route designators and point triples. We capture every point triple seen
    # after a plausible route designator. Duplicates are removed later.
    i = 0
    while i < len(lines):
        line = lines[i].strip().upper()
        if ROUTE_RE.fullmatch(line) and any(ch.isdigit() for ch in line):
            current_route = line
            seq_by_route.setdefault(current_route, 0)
            i += 1
            continue
        if current_route and i + 2 < len(lines):
            code = lines[i].strip().upper()
            lat = lines[i + 1].strip().upper()
            lon = lines[i + 2].strip().upper()
            if POINT_RE.match(code) and LAT_RE.match(lat) and LON_RE.match(lon):
                seq_by_route[current_route] += 1
                out.append({
                    "airway": current_route,
                    "seq": str(seq_by_route[current_route]),
                    "point": code,
                    "lat": f"{dms_to_dd(lat, False):.6f}",
                    "lon": f"{dms_to_dd(lon, True):.6f}",
                    "route_type": "RNAV5" if current_route.startswith("U") or current_route.startswith("Z") or current_route.startswith("Y") else "ATS",
                    "lower": "",
                    "upper": "",
                    "mea": "",
                    "remarks": "ENR 3.3 parsed",
                })
                i += 3
                continue
        i += 1

    # De-dupe repeated rows, preserving order.
    seen = set()
    cleaned: List[Dict[str, str]] = []
    last_point_by_airway: Dict[str, str] = {}
    seq_counter: Dict[str, int] = {}
    for row in out:
        key_pair = (row["airway"], row["point"])
        # Keep non-consecutive repeats only if the route genuinely loops; most eAIP repeats are layout repeats.
        if last_point_by_airway.get(row["airway"]) == row["point"]:
            continue
        if key_pair in seen:
            continue
        seen.add(key_pair)
        last_point_by_airway[row["airway"]] = row["point"]
        seq_counter[row["airway"]] = seq_counter.get(row["airway"], 0) + 1
        row["seq"] = str(seq_counter[row["airway"]])
        cleaned.append(row)
    return cleaned


def write_csv(path: Path, rows: List[Dict[str, str]], fields: List[str]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", newline="", encoding="utf-8") as f:
        w = csv.DictWriter(f, fieldnames=fields)
        w.writeheader()
        for r in rows:
            w.writerow({k: r.get(k, "") for k in fields})


def main() -> None:
    print("A descarregar ENR 4.4…")
    points = parse_enr44()
    if not points:
        raise SystemExit("Não consegui extrair pontos ENR 4.4.")
    points_by_code = {p["code"]: p for p in points}
    print(f"Pontos ENR 4.4: {len(points)}")
    print("A descarregar ENR 3.3…")
    airways = parse_enr33(points_by_code)
    print(f"Linhas de airway ENR 3.3: {len(airways)}")
    write_csv(ROOT / "IFR_POINTS.csv", points, ["code", "name", "lat", "lon", "routes", "remarks", "src"])
    write_csv(ROOT / "IFR_AIRWAYS.csv", airways, ["airway", "seq", "point", "lat", "lon", "route_type", "lower", "upper", "mea", "remarks"])
    print("OK: IFR_POINTS.csv e IFR_AIRWAYS.csv atualizados.")
    print("Valida visualmente os CSV antes de uso operacional.")


if __name__ == "__main__":
    main()
